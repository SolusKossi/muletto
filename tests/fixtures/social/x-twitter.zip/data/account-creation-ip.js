window.YTD.account_creation_ip.part0 = [
 {
  "accountCreationIp": {
   "accountId": "111111",
   "userCreationIp": "203.0.113.7"
  }
 }
]