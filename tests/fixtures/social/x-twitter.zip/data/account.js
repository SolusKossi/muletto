window.YTD.account.part0 = [
 {
  "account": {
   "accountId": "111111",
   "username": "fixture",
   "email": "fixture@example.invalid",
   "createdAt": "2011-04-02T09:00:00.000Z"
  }
 }
]