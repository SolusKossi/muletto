window.YTD.direct_messages.part0 = [
 {
  "dmConversation": {
   "conversationId": "111111-222222",
   "messages": [
    {
     "messageCreate": {
      "recipientId": "222222",
      "senderId": "222222",
      "text": "Message 0",
      "createdAt": "2025-10-05T10:00:00.000Z"
     }
    },
    {
     "messageCreate": {
      "recipientId": "222222",
      "senderId": "111111",
      "text": "Message 1",
      "createdAt": "2025-11-05T10:01:00.000Z"
     }
    },
    {
     "messageCreate": {
      "recipientId": "222222",
      "senderId": "222222",
      "text": "Message 2",
      "createdAt": "2025-10-05T10:02:00.000Z"
     }
    },
    {
     "messageCreate": {
      "recipientId": "222222",
      "senderId": "111111",
      "text": "Message 3",
      "createdAt": "2025-11-05T10:03:00.000Z"
     }
    },
    {
     "messageCreate": {
      "recipientId": "222222",
      "senderId": "222222",
      "text": "Message 4",
      "createdAt": "2025-10-05T10:04:00.000Z"
     }
    },
    {
     "messageCreate": {
      "recipientId": "222222",
      "senderId": "111111",
      "text": "Message 5",
      "createdAt": "2025-11-05T10:05:00.000Z"
     }
    }
   ]
  }
 }
]