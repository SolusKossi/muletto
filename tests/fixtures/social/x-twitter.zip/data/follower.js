window.YTD.follower.part0 = [
 {
  "follower": {
   "accountId": "333330"
  }
 },
 {
  "follower": {
   "accountId": "333331"
  }
 },
 {
  "follower": {
   "accountId": "333332"
  }
 }
]