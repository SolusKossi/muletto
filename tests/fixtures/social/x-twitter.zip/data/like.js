window.YTD.like.part0 = [
 {
  "like": {
   "tweetId": "9000",
   "fullText": "Liked 0"
  }
 },
 {
  "like": {
   "tweetId": "9001",
   "fullText": "Liked 1"
  }
 },
 {
  "like": {
   "tweetId": "9002",
   "fullText": "Liked 2"
  }
 },
 {
  "like": {
   "tweetId": "9003",
   "fullText": "Liked 3"
  }
 }
]