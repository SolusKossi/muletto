window.YTD.note_tweet.part0 = [
 {
  "noteTweet": {
   "noteTweetId": "100000000000000009",
   "noteTweetResults": {
    "result": {
     "id": "100000000000000009",
     "text": "A post long enough that X truncates it in the main file: the rest of this sentence only exists in note-tweet.js, and a reader that never opens that file loses it without a word."
    }
   }
  }
 }
]