window.YTD.tweet.part0 = [
 {
  "tweet": {
   "id_str": "100000000000000020",
   "created_at": "Tue Feb 01 09:00:00 +0100 2024",
   "full_text": "Older post 0",
   "favorite_count": "1",
   "retweet_count": "0"
  }
 },
 {
  "tweet": {
   "id_str": "100000000000000021",
   "created_at": "Tue Feb 02 09:00:00 +0100 2024",
   "full_text": "Older post 1",
   "favorite_count": "1",
   "retweet_count": "0"
  }
 },
 {
  "tweet": {
   "id_str": "100000000000000022",
   "created_at": "Tue Feb 03 09:00:00 +0100 2024",
   "full_text": "Older post 2",
   "favorite_count": "1",
   "retweet_count": "0"
  }
 }
]