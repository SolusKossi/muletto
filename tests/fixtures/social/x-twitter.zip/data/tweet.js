window.YTD.tweet.part0 = [
 {
  "tweet": {
   "id_str": "100000000000000000",
   "created_at": "Wed Oct 10 20:19:24 +0000 2025",
   "full_text": "Post number 0, with a link https://example.invalid/0",
   "favorite_count": "0",
   "retweet_count": "0",
   "entities": {
    "hashtags": [],
    "urls": []
   }
  }
 },
 {
  "tweet": {
   "id_str": "100000000000000001",
   "created_at": "Wed Oct 11 20:19:24 +0000 2025",
   "full_text": "Post number 1, with a link https://example.invalid/1",
   "favorite_count": "2",
   "retweet_count": "1",
   "entities": {
    "hashtags": [],
    "urls": []
   }
  }
 },
 {
  "tweet": {
   "id_str": "100000000000000002",
   "created_at": "Wed Oct 12 20:19:24 +0000 2025",
   "full_text": "Post number 2, with a link https://example.invalid/2",
   "favorite_count": "4",
   "retweet_count": "2",
   "entities": {
    "hashtags": [],
    "urls": []
   }
  }
 },
 {
  "tweet": {
   "id_str": "100000000000000003",
   "created_at": "Wed Oct 13 20:19:24 +0000 2025",
   "full_text": "Post number 3, with a link https://example.invalid/3",
   "favorite_count": "6",
   "retweet_count": "3",
   "entities": {
    "hashtags": [],
    "urls": []
   }
  }
 },
 {
  "tweet": {
   "id_str": "100000000000000004",
   "created_at": "Wed Oct 14 20:19:24 +0000 2025",
   "full_text": "Post number 4, with a link https://example.invalid/4",
   "favorite_count": "8",
   "retweet_count": "4",
   "entities": {
    "hashtags": [],
    "urls": []
   }
  }
 },
 {
  "tweet": {
   "id_str": "100000000000000005",
   "created_at": "Wed Oct 15 20:19:24 +0000 2025",
   "full_text": "Post number 5, with a link https://example.invalid/5",
   "favorite_count": "10",
   "retweet_count": "5",
   "entities": {
    "hashtags": [],
    "urls": []
   }
  }
 },
 {
  "tweet": {
   "id_str": "100000000000000006",
   "created_at": "Wed Oct 16 20:19:24 +0000 2025",
   "full_text": "Post number 6, with a link https://example.invalid/6",
   "favorite_count": "12",
   "retweet_count": "6",
   "entities": {
    "hashtags": [],
    "urls": []
   }
  }
 },
 {
  "tweet": {
   "id_str": "100000000000000007",
   "created_at": "Wed Oct 17 20:19:24 +0000 2025",
   "full_text": "Post number 7, with a link https://example.invalid/7",
   "favorite_count": "14",
   "retweet_count": "7",
   "entities": {
    "hashtags": [],
    "urls": []
   }
  }
 },
 {
  "tweet": {
   "id_str": "100000000000000008",
   "created_at": "Wed Oct 18 20:19:24 +0000 2025",
   "full_text": "Post number 8, with a link https://example.invalid/8",
   "favorite_count": "16",
   "retweet_count": "8",
   "entities": {
    "hashtags": [],
    "urls": []
   }
  }
 },
 {
  "tweet": {
   "id_str": "100000000000000009",
   "created_at": "Mon Jan 06 08:00:00 +0000 2025",
   "full_text": "A post long enough that X truncates it in the main file: the...",
   "favorite_count": "40",
   "retweet_count": "11"
  }
 },
 {
  "tweet": {
   "id_str": "100000000000000010",
   "created_at": "sometime last spring",
   "full_text": "Undated post",
   "favorite_count": "0",
   "retweet_count": "0"
  }
 }
]